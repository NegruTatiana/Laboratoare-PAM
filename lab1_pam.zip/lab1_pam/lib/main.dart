import 'package:flutter/material.dart';

void main() {//punctul de start a aplicatiei
  runApp(const MaterialApp( //porneste aplicatia
    home: CalculatorPage(), //prima pagina care se afiseaza
    debugShowCheckedModeBanner: false, //scoate bannerul debug din coltul ecranului
  ));
}

//CalculatorPage este un widget cu stare, adica continutul lui se poate schimba
class CalculatorPage extends StatefulWidget{
  const CalculatorPage({super.key});//constructorul widget-ului, key ajuta Flutter sa identifice widget-ul

  @override //folosim overide ca daca facem o greseala in valori, compilatorul imi va da eroare
  State<CalculatorPage> createState()=>_CalculatorPageState(); //state-ul descrie cum se comporta si ce valori are

}

//clasa unde tine variabila si logica
class _CalculatorPageState extends State<CalculatorPage> {
  final TextEditingController distantaController = TextEditingController();

  final TextEditingController timpController = TextEditingController(); //TextEditingController - controleaza ce scrie utilizatorul
  double? vitezaMedie; //rezultatul calcului vitezei, poate fi null daca nu e calculata

  void calculeazaViteza() {
    final double? distanta = double.tryParse(distantaController.text);
    final double? timp = double.tryParse(timpController.text);

    if (distanta != null && timp != null && timp > 0) {
      setState(() {
        vitezaMedie = distanta / timp;
      });
    }
    else {
      setState(() {
        vitezaMedie = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) //creaza interfata paginii
  {
    return Scaffold( //structura de baza a paginii(bara, continut, butoane
      appBar: AppBar(title: const Text("Calculator Viteza Medie")),
      //bara de sus cu titlul paginii
      body: Padding( //spatiul in jurul continutului
        padding: const EdgeInsets.all(16), //16 pixeli spatiu
        child: Column( //aranjeaza widget-urile vertical, unul sub altul
            children: [
              //lista de widget-uri dintr o coloana
              TextField(
                controller: distantaController, //preia ce scrie utilizatorul
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Distanta (km)"),
              ),
              TextField(
                controller: timpController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Timpul (ore)"),
              ),
              const SizedBox(height: 16),
              //adauga spatiu vertical intre widget-uri

              ElevatedButton(onPressed: calculeazaViteza, child: const Text("Calculeaza")
              ),

              const SizedBox(height: 16),
              if (vitezaMedie!=null)
                Text("Viteza medie: ${vitezaMedie!.toStringAsFixed(2)} km/h"),
            ],
        ),
      ),
    );
  }
}

