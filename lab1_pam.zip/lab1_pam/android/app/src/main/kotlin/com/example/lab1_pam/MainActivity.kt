package com.example.lab1_pam

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
